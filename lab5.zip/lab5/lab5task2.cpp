#include <stdio.h>
int main() {
    int n ;
    printf("Enter an integer :");
    scanf("%d", &n  ); 
	(n%2==0) ? printf("Even number"):
		(n%3 == 0 ) ? printf("Divisible by 3 ") :
		            printf("Odd and not divisible by 3") ;
			return 0;
		}
		
		
