
#include <stdio.h>

int main() {
    int m1, m2, m3, largest;

    printf("Enter marks of first student: ");
    scanf("%d", &m1);
    printf("Enter marks of second student: ");
    scanf("%d", &m2);
    printf("Enter marks of third student: ");
    scanf("%d", &m3);

    largest = (m1 > m2) ? 
                 ((m1 > m3) ? m1 : m3) : 
                 ((m2 > m3) ? m2 : m3);

    printf("The largest mark is: %d\n", largest);

    return 0;
}


