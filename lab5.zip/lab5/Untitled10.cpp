
#include <stdio.h>

void print_binary(int n) {
    for (int i = 7; i >= 0; i--) {
        printf("%d", (n >> i) & 1);
        if (i % 4 == 0 && i != 0) printf(" ");
    }
}

int main() {
    int a = 13, b = 10;
    int and_res = a & b;
    int xor_res = a ^ b;
    int or_res = and_res | xor_res;
    int a_or_b = a | b;

    printf("a = "); print_binary(a); printf(" (%d)\n", a);
    printf("b = "); print_binary(b); printf(" (%d)\n\n", b);

    printf("a & b = "); print_binary(and_res); printf(" (%d)\n", and_res);
    printf("a ^ b = "); print_binary(xor_res); printf(" (%d)\n", xor_res);
    printf("(a & b) | (a ^ b) = "); print_binary(or_res); printf(" (%d)\n\n", or_res);

    printf("a | b = "); print_binary(a_or_b); printf(" (%d)\n\n", a_or_b);

    if (or_res == a_or_b)
        printf("Result: Equal\n");
    else
        printf("Result: Not Equal\n");

    return 0;
}


