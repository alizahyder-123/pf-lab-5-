
#include <stdio.h>

int main() {
    int sectionChoice, sizeChoice, qty, typeChoice;
    float price = 0, total = 0;

    printf("Welcome to Our Restaurant!\n");
    printf("1. Coffee Shop\n");
    printf("2. Burger Hub\n");
    printf("3. Ice Cream Parlour\n");
    printf("Enter your choice: ");
    scanf("%d", &sectionChoice);

    switch (sectionChoice) {
        case 1: // Coffee Shop
            printf("\nWelcome to Coffee Shop!\n");
            printf("Choose coffee size:\n");
            printf("1. Small (200)\n");
            printf("2. Medium (300)\n");
            printf("3. Large (400)\n");
            scanf("%d", &sizeChoice);

            if (sizeChoice == 1) price = 200;
            else if (sizeChoice == 2) price = 300;
            else if (sizeChoice == 3) price = 400;
            else {
                printf("Invalid size choice.\n");
                return 0;
            }

            printf("Enter number of coffees: ");
            scanf("%d", &qty);

            if (qty > 1) {
                printf("Check our combo offers!\n");
                // Example combo: Buy 2, get 10% off
                if (qty >= 2) {
                    total = (price * qty) * 0.9;
                } else {
                    total = price * qty;
                }
            } else {
                total = price * qty;
            }

            printf("Choose coffee type:\n");
            printf("1. Regular\n");
            printf("2. Cappuccino\n");
            printf("3. Latte\n");
            scanf("%d", &typeChoice);

            printf("\n----- BILL -----\n");
            printf("Coffee size: %s\n", 
                   (sizeChoice == 1) ? "Small" : 
                   (sizeChoice == 2) ? "Medium" : "Large");
            printf("Coffee type: %s\n", 
                   (typeChoice == 1) ? "Regular" : 
                   (typeChoice == 2) ? "Cappuccino" : "Latte");
            printf("Quantity: %d\n", qty);
            printf("Total: %.2f\n", total);
            printf("----------------\n");
            break;

        case 2:
            printf("Your order will be handled by Burger Hub.\n");
            break;

        case 3:
            printf("Your order will be handled by Ice Cream Parlour.\n");
            break;

        default:
            printf("Invalid section choice.\n");
    }

    return 0;
}


