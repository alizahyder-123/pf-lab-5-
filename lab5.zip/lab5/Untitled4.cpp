
#include <stdio.h>

int main() {
    float attendance;
    char midterm, fee;

    printf("Enter attendance percentage: ");
    scanf("%f", &attendance);

    if (attendance < 75) {
        printf("You are not eligible for the Final Exam (attendance below 75%%)\n");
    } else {
        printf("Did you clear the midterm? (P for Pass, F for Fail): ");
        scanf(" %c", &midterm);

        if (midterm == 'F' || midterm == 'f') {
            printf("You are not eligible for the Final Exam (failed midterm)\n");
        } else {
            printf("Have you paid the exam fee? (Y for Yes, N for No): ");
            scanf(" %c", &fee);

            if (fee == 'Y' || fee == 'y') {
                printf("You are eligible for the Final Exam\n");
            } else {
                printf("Please clear your dues to appear in the Final Exam\n");
            }
        }
    }

    return 0;
}


