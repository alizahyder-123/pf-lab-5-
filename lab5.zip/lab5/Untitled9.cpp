#include <stdio.h>

int main(void) {
    /* hardcoded values -- change these to test other cases */
    int x = 2;
    int y = 3;
    int z = 4;

    printf("Expression: x + y * z > 10 && x - z < y || !(y %% z)\n");
    printf("Hardcoded values: x=%d, y=%d, z=%d\n\n", x, y, z);

    /* 1) show grouping by precedence */
    printf("1) Grouping by C operator precedence (how the expression is parsed):\n");
    printf("   - y * z\n");
    printf("   - x + (y * z)\n");
    printf("   - (x + y*z) > 10\n");
    printf("   - x - z\n");
    printf("   - (x - z) < y\n");
    printf("   - y %% z\n");
    printf("   - !(y %% z)\n");
    printf("   - ((x + y*z) > 10 && (x - z) < y) || !(y %% z)\n\n");

    /* 2) manual / intermediate evaluation (respecting grouping) */
    printf("2) Intermediate values of each subexpression:\n");
    int t_yz     = y * z;                 printf("   y * z = %d\n", t_yz);
    int t_xplus  = x + t_yz;              printf("   x + y*z = %d\n", t_xplus);
    int t_gt10   = (t_xplus > 10);        printf("   (x + y*z) > 10 -> %d\n", t_gt10);
    int t_xminus = x - z;                 printf("   x - z = %d\n", t_xminus);
    int t_lt_y   = (t_xminus < y);        printf("   (x - z) < y -> %d\n", t_lt_y);
    int t_mod    = (z != 0) ? (y % z) : 0; printf("   y %% z = %d\n", t_mod);
    int t_notmod = !t_mod;                printf("   !(y %% z) -> %d\n", t_notmod);

    int t_and    = t_gt10 && t_lt_y;      printf("   (x+y*z > 10) && (x-z < y) -> %d\n", t_and);
    int final_manual = t_and || t_notmod; printf("   Final (manual combination) -> %d\n\n", final_manual);

    /* 3) final result computed by C (same logical expression) */
    printf("3) Final result computed by C for the full expression -> %d\n",
           ( (x + y * z > 10 && x - z < y) || !(y % z) ) );

    return 0;
}

