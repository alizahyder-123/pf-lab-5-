		#include <stdio.h>
  #include <math.h>
  #define PI 3.141592653589793

    int cal () {
    double radius, area, circumference, root;

    printf("Enter the radius of the tank: ");
    scanf("%lf", &radius);

    area = PI * pow(radius, 2);      
    circumference = 2 * PI * radius; 
    root = sqrt(radius);             

    printf("Area: %.2f\n", area);
    printf("Circumference: %.2f\n", circumference);
    printf("Square root of radius: %.2f\n", root);

    return 0;
}

