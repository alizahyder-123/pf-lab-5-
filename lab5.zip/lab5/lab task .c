#include <stdio.h>
#include <math.h>
#define PI 3.141592653589793

int main() {
    double radius, area, circumference, root;

    printf("Enter the radius of the tank: ");
    scanf("%lf", &radius);

    area = PI * pow(radius, 2);      // pr�
    circumference = 2 * PI * radius; // 2pr
    root = sqrt(radius);             // vr

    printf("Area: %.2f\n", area);
    printf("Circumference: %.2f\n", circumference);
    printf("Square root of radius: %.2f\n", root);
    return 0;
}

