
#include <stdio.h>

int main() {
    int pin = 1234;       // Preset PIN
    int enteredPin;
    int balance = 10000;  // Initial balance
    int withdraw;

    printf("Enter 4-digit PIN: ");
    scanf("%d", &enteredPin);

    if (enteredPin == pin) {
        printf("Enter withdrawal amount: ");
        scanf("%d", &withdraw);

        if (withdraw > balance) {
            printf("Insufficient Balance\n");
        } else {
            balance -= withdraw;
            printf("Withdrawal Successful!\n");
            printf("Remaining Balance: %d\n", balance);
        }
    } else {
        printf("Incorrect PIN\n");
    }

    return 0;
}


